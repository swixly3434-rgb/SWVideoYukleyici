package com.sw.videoyukleyici

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Linkten video bilgisini ve tüm kalite seçeneklerini çıkarır. */
object Extractor {

    @Volatile
    private var currentPid: String? = null

    fun cancelCurrent() {
        val pid = currentPid ?: return
        currentPid = null
        runCatching { YoutubeDL.getInstance().destroyProcessById(pid) }
    }

    suspend fun fetch(url: String): VideoDetails {
        cancelCurrent()
        return withContext(Dispatchers.IO) {
            Engine.await()
            val pid = "info-" + System.nanoTime()
            currentPid = pid
            val req = YoutubeDLRequest(url)
            req.addOption("--dump-single-json")
            req.addOption("--no-playlist")
            req.addOption("--no-warnings")
            req.addOption("--socket-timeout", "20")
            val out = try {
                YoutubeDL.getInstance().execute(request = req, processId = pid).out
            } finally {
                if (currentPid == pid) currentPid = null
            }
            parse(url, out)
        }
    }

    // ---------------------------------------------------------------- JSON yardımcıları

    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun num(o: JSONObject, k: String): Double {
        if (o.isNull(k)) return 0.0
        val d = o.optDouble(k, 0.0)
        return if (d.isNaN()) 0.0 else d
    }

    private class Fmt(
        val id: String,
        val w: Int,
        val h: Int,
        val v: String,      // vcodec
        val a: String,      // acodec
        val ext: String,
        val tbr: Double,
        val abr: Double,
        val size: Long,
        val note: String
    )

    private fun codecRank(v: String): Int = when {
        v.startsWith("avc1") || v.startsWith("h264") -> 3   // her cihazda oynar
        v.startsWith("vp09") || v.startsWith("vp9") -> 2
        v.startsWith("hev") || v.startsWith("h265") -> 1
        v.startsWith("av01") -> 0
        else -> 2
    }

    private val noteRegex = Regex("^(\\d{3,4})p")
    private val safeIdRegex = Regex("^[A-Za-z0-9_.-]+$")

    /** 1080x1920 dikey videolar da "1080p" sayılsın diye kısa kenar esas alınır. */
    private fun labelOf(f: Fmt): Int {
        val m = noteRegex.find(f.note)
        if (m != null) return m.groupValues[1].toInt()
        return if (f.w in 1 until f.h) f.w else f.h
    }

    private fun badgeOf(p: Int): String = when {
        p >= 4320 -> "8K"
        p >= 2160 -> "4K"
        p >= 1440 -> "2K"
        p >= 1080 -> "Full HD"
        p >= 720 -> "HD"
        else -> ""
    }

    private fun parse(url: String, raw: String): VideoDetails {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) throw IllegalStateException("Video bilgisi okunamadı")
        val j = JSONObject(raw.substring(s, e + 1))

        val title = str(j, "title").ifBlank { str(j, "fulltitle") }.ifBlank { "Video" }
        val uploader = str(j, "uploader").ifBlank { str(j, "channel") }.ifBlank { str(j, "uploader_id") }
        val site = str(j, "extractor_key").ifBlank { str(j, "extractor") }
        val duration = num(j, "duration").toLong()

        var thumb: String? = str(j, "thumbnail").ifBlank { null }
        if (thumb == null) {
            val ta = j.optJSONArray("thumbnails")
            if (ta != null) {
                for (i in ta.length() - 1 downTo 0) {
                    val u = ta.optJSONObject(i)?.let { str(it, "url") }.orEmpty()
                    if (u.startsWith("http")) { thumb = u; break }
                }
            }
        }

        val fmts = mutableListOf<Fmt>()
        val arr = j.optJSONArray("formats")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val ext = str(o, "ext")
                if (ext == "mhtml" || str(o, "protocol").contains("mhtml")) continue
                fmts += Fmt(
                    id = str(o, "format_id"),
                    w = num(o, "width").toInt(),
                    h = num(o, "height").toInt(),
                    v = str(o, "vcodec"),
                    a = str(o, "acodec"),
                    ext = ext,
                    tbr = num(o, "tbr"),
                    abr = num(o, "abr"),
                    size = maxOf(num(o, "filesize"), num(o, "filesize_approx")).toLong(),
                    note = str(o, "format_note")
                )
            }
        }

        // --- en iyi ses (video-only formatlara eklenecek)
        val audios = fmts.filter { it.v == "none" && it.a.isNotEmpty() && it.a != "none" }
        fun audioScore(f: Fmt) = if (f.abr > 0) f.abr else f.tbr
        val bestAudio = audios.filter { it.ext == "m4a" }.maxByOrNull { audioScore(it) }
            ?: audios.maxByOrNull { audioScore(it) }
        val audioBytes = bestAudio?.let {
            when {
                it.size > 0 -> it.size
                audioScore(it) > 0 && duration > 0 -> (audioScore(it) * 1000 / 8 * duration).toLong()
                else -> 0L
            }
        } ?: 0L

        // --- video kaliteleri: her çözünürlük etiketi için en uyumlu tek format
        val videos = fmts.filter {
            it.id.isNotEmpty() && it.h > 0 && it.v != "none" && !it.note.contains("Premium", ignoreCase = true)
        }
        val qualities = mutableListOf<Quality>()
        val groups = videos.groupBy { labelOf(it) }.filterKeys { it > 0 }
        for (label in groups.keys.sortedDescending()) {
            val list = groups.getValue(label)
            val best = list.maxWithOrNull(
                compareBy<Fmt>({ codecRank(it.v) }, { it.tbr }, { it.size })
            ) ?: list.first()

            val muxed = best.a != "none"          // sesi zaten içinde
            val vBytes = when {
                best.size > 0 -> best.size
                best.tbr > 0 && duration > 0 -> (best.tbr * 1000 / 8 * duration).toLong()
                else -> 0L
            }
            val aBytes = if (muxed) 0L else audioBytes

            val selector = if (safeIdRegex.matches(best.id)) {
                if (muxed) best.id
                else "${best.id}+ba[ext=m4a]/${best.id}+ba/${best.id}"
            } else {
                val h = best.h
                if (muxed) "b[height<=$h]" else "bv*[height<=$h]+ba/b[height<=$h]"
            }
            val share = when {
                muxed || bestAudio == null -> 1f
                vBytes > 0 && aBytes > 0 -> (vBytes.toFloat() / (vBytes + aBytes)).coerceIn(0.5f, 0.98f)
                else -> 0.85f
            }
            qualities += Quality(
                label = "${label}p",
                badge = badgeOf(label),
                sizeBytes = if (vBytes > 0) vBytes + aBytes else 0L,
                selector = selector,
                audioOnly = false,
                videoShare = share
            )
        }

        // --- sadece ses (MP3)
        val hasAudio = bestAudio != null || videos.isNotEmpty() || fmts.isEmpty()
        if (hasAudio) {
            qualities += Quality(
                label = "MP3",
                badge = "Sadece ses",
                sizeBytes = if (duration > 0) duration * 30_000L else 0L,   // ~240 kbps tahmini
                selector = "ba/b",
                audioOnly = true,
                videoShare = 1f
            )
        }

        // --- hiç format listesi yoksa (tek dosya linki vb.) en iyi kaliteyi sun
        if (qualities.none { !it.audioOnly } && videos.isEmpty() && audios.isEmpty()) {
            qualities.add(
                0,
                Quality("En iyi kalite", "", 0L, "bv*+ba/b", false, 0.85f)
            )
        }

        return VideoDetails(
            url = url,
            title = title,
            uploader = uploader,
            site = site,
            thumbnail = thumb,
            durationSec = duration,
            qualities = qualities
        )
    }

    // ---------------------------------------------------------------- Hata mesajları

    fun friendly(e: Throwable): String {
        val raw = e.message ?: e.toString()
        val line = raw.lines().lastOrNull { it.contains("ERROR", ignoreCase = true) }
            ?: raw.lines().lastOrNull { it.isNotBlank() }
            ?: raw
        val l = line.lowercase()
        return when {
            "unsupported url" in l ->
                "Bu bağlantı desteklenmiyor. Bir video bağlantısı girdiğinizden emin olun."
            "sign in to confirm" in l || "not a bot" in l ->
                "YouTube şu an doğrulama istiyor. Biraz sonra tekrar deneyin ya da üstteki yenile simgesiyle yt-dlp'yi güncelleyin."
            "login required" in l || "log in" in l || "private" in l || "cookies" in l ||
                "rate-limit" in l || "empty media response" in l ->
                "Bu içerik özel olabilir ya da giriş gerektiriyor (Instagram bazı paylaşımlarda bunu ister)."
            "video unavailable" in l || "not available" in l || "has been removed" in l ->
                "Bu video kullanılamıyor (silinmiş, gizli ya da bölgenize kapalı olabilir)."
            "unable to download" in l || "timed out" in l || "name or service" in l ||
                "network" in l || "connection" in l ->
                "Bağlantı sorunu. İnternetinizi kontrol edip tekrar deneyin."
            "no space" in l -> "Depolama alanı yetersiz."
            else -> line.replace(Regex("^\\s*ERROR:\\s*", RegexOption.IGNORE_CASE), "").trim().take(220)
        }
    }
}
