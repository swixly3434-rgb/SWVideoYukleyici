package com.sw.videoyukleyici

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {

    var url by mutableStateOf("")
        private set
    var updating by mutableStateOf(false)
        private set

    private val _state = MutableStateFlow<UiState>(UiState.Idle)
    val state: StateFlow<UiState> = _state

    val downloads = DownloadStore.items

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events

    private var job: Job? = null
    private var lastAnalyzed: String? = null

    /** Kutuya yazı yazılınca / yapıştırılınca çağrılır. Geçerli bir link algılanırsa otomatik analiz eder. */
    fun onUrlChange(v: String) {
        url = v
        job?.cancel()
        val u = UrlUtil.extract(v)
        if (v.isBlank()) {
            Extractor.cancelCurrent()
            lastAnalyzed = null
            _state.value = UiState.Idle
            return
        }
        if (u == null || !UrlUtil.looksComplete(u)) return
        if (u == lastAnalyzed && _state.value is UiState.Ready) return
        job = viewModelScope.launch {
            delay(800)
            analyze(u)
        }
    }

    fun analyzeNow() {
        val u = UrlUtil.extract(url)
        if (u == null) {
            _state.value = UiState.Error("Geçerli bir video bağlantısı girin.")
            return
        }
        job?.cancel()
        job = viewModelScope.launch { analyze(u) }
    }

    fun clear() {
        job?.cancel()
        Extractor.cancelCurrent()
        url = ""
        lastAnalyzed = null
        _state.value = UiState.Idle
    }

    private suspend fun analyze(u: String) {
        _state.value = UiState.Loading
        try {
            val d = Extractor.fetch(u)
            lastAnalyzed = u
            _state.value = UiState.Ready(d)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            // iptal edilmiş eski bir aramanın hatası ekrana yansımasın
            currentCoroutineContext().ensureActive()
            _state.value = UiState.Error(Extractor.friendly(e))
        }
    }

    fun download(d: VideoDetails, q: Quality) {
        val item = DownloadItem(
            id = UUID.randomUUID().toString(),
            url = d.url,
            title = d.title,
            thumbnail = d.thumbnail,
            qualityLabel = q.label,
            selector = q.selector,
            audioOnly = q.audioOnly,
            videoShare = q.videoShare
        )
        DownloadStore.add(item)
        Downloads.start(getApplication(), item)
        _events.tryEmit("İndirme başladı • ${q.label}")
    }

    fun cancel(item: DownloadItem) = Downloads.cancel(getApplication(), item.id)

    fun retry(item: DownloadItem) = Downloads.retry(getApplication(), item)

    fun remove(item: DownloadItem) = DownloadStore.remove(item.id)

    fun updateEngine() {
        if (updating) return
        updating = true
        viewModelScope.launch {
            val msg = try {
                Engine.update(getApplication())
            } catch (e: Throwable) {
                "Güncelleme başarısız: " + (e.message ?: "bilinmeyen hata").take(120)
            }
            updating = false
            _events.tryEmit(msg)
        }
    }
}
