package com.sw.videoyukleyici

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** İndirmeyi başlatan / iptal eden yardımcı. */
object Downloads {
    fun start(ctx: Context, item: DownloadItem) {
        val req = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(workDataOf(DownloadWorker.KEY_ID to item.id))
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .addTag("sw-download")
            .build()
        WorkManager.getInstance(ctx.applicationContext)
            .enqueueUniqueWork("dl-${item.id}", ExistingWorkPolicy.REPLACE, req)
    }

    fun retry(ctx: Context, item: DownloadItem) {
        val fresh = item.copy(
            status = DlStatus.QUEUED, progress = 0f, eta = 0L, error = null, uri = null, mime = null
        )
        DownloadStore.add(fresh)
        start(ctx, fresh)
    }

    fun cancel(ctx: Context, id: String) {
        DownloadStore.update(id) { if (it.status.isActive) it.copy(status = DlStatus.CANCELED) else it }
        WorkManager.getInstance(ctx.applicationContext).cancelUniqueWork("dl-$id")
        runCatching { YoutubeDL.getInstance().destroyProcessById("dl-$id") }
    }
}

class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        const val KEY_ID = "id"
    }

    private val itemId: String get() = inputData.getString(KEY_ID).orEmpty()
    private val processId: String get() = "dl-$itemId"
    private val notifId: Int get() = itemId.hashCode()
    private val nm: NotificationManager
        get() = applicationContext.getSystemService(NotificationManager::class.java)

    // ilerleme takibi
    private var stage = 0
    private var lastPct = 0f
    private var lastNotifPct = -1
    private var lastNotifAt = 0L

    override suspend fun getForegroundInfo(): ForegroundInfo {
        val title = DownloadStore.get(itemId)?.title ?: "İndiriliyor"
        return ForegroundInfo(
            notifId,
            progressNotification(title, 0, true, "Hazırlanıyor…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
    }

    override suspend fun doWork(): Result {
        val item = DownloadStore.get(itemId) ?: return Result.success()
        if (item.status != DlStatus.QUEUED) return Result.success()

        try {
            setForeground(getForegroundInfo())
        } catch (_: Exception) {
            // arka planda başlatma izni yoksa bile indirme devam eder
        }
        DownloadStore.updateIfActive(itemId) { it.copy(status = DlStatus.RUNNING, progress = 0f) }

        val tmp = File(applicationContext.externalCacheDir ?: applicationContext.cacheDir, "dl/$itemId")
        return try {
            Engine.await()
            tmp.deleteRecursively()
            tmp.mkdirs()

            coroutineScope {
                // İş iptal edilirse (ör. bildirimdeki İptal) yt-dlp işlemini de öldür
                val killer = launch {
                    try {
                        awaitCancellation()
                    } finally {
                        runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
                    }
                }
                try {
                    withContext(Dispatchers.IO) { runYtDlp(item, tmp) }
                } finally {
                    killer.cancel()
                }
            }

            val file = findOutput(tmp) ?: throw IOException("İndirilen dosya bulunamadı")
            DownloadStore.updateIfActive(itemId) { it.copy(status = DlStatus.MERGING, progress = 99f) }
            val (uri, mime) = saveToGallery(file, item.title, item.audioOnly)
            val size = file.length()
            DownloadStore.update(itemId) {
                it.copy(
                    status = DlStatus.DONE, progress = 100f, eta = 0L,
                    uri = uri.toString(), mime = mime, sizeBytes = size, error = null
                )
            }
            notifyDone(item.title, uri, mime)
            Result.success()
        } catch (e: Throwable) {
            val canceled = e is CancellationException || isStopped ||
                DownloadStore.get(itemId)?.status == DlStatus.CANCELED
            if (canceled) {
                DownloadStore.update(itemId) { if (it.status == DlStatus.DONE) it else it.copy(status = DlStatus.CANCELED) }
                if (e is CancellationException) throw e
                Result.failure()
            } else {
                val msg = Extractor.friendly(e)
                DownloadStore.update(itemId) { it.copy(status = DlStatus.FAILED, error = msg) }
                notifyFailed(item.title, msg)
                Result.failure()
            }
        } finally {
            runCatching { tmp.deleteRecursively() }
            runCatching { nm.cancel(notifId) }
        }
    }

    // ------------------------------------------------------------------ yt-dlp

    private fun runYtDlp(item: DownloadItem, dir: File) {
        val req = YoutubeDLRequest(item.url)
        req.addOption("--no-playlist")
        req.addOption("--no-mtime")
        req.addOption("--retries", "5")
        req.addOption("--fragment-retries", "5")
        req.addOption("--concurrent-fragments", "4")
        req.addOption("-f", item.selector)
        if (item.audioOnly) {
            req.addOption("-x")
            req.addOption("--audio-format", "mp3")
            req.addOption("--audio-quality", "0")
        } else {
            req.addOption("--merge-output-format", "mp4/mkv")
        }
        req.addOption("-o", File(dir, "dl.%(ext)s").absolutePath)

        stage = 0
        lastPct = 0f
        YoutubeDL.getInstance().execute(
            request = req,
            processId = processId,
            callback = { progress, eta, line -> onProgress(item, progress, eta, line) }
        )
    }

    private fun onProgress(item: DownloadItem, p: Number, eta: Number, line: Any?) {
        val text = line?.toString().orEmpty()
        if (text.contains("[Merger]") || text.contains("[ExtractAudio]") ||
            text.contains("[VideoRemuxer]") || text.contains("[VideoConvertor]") ||
            text.contains("[ffmpeg]")
        ) {
            DownloadStore.updateIfActive(itemId) { it.copy(status = DlStatus.MERGING, progress = 99f, eta = 0L) }
            pushNotification(item.title, 99, true, "İşleniyor…")
            return
        }
        val pv = p.toFloat()
        if (pv < 0f || pv > 100f) return

        // video + ses ayrı indirilir: ilerleme geri sarınca ikinci aşamaya geç
        if (item.videoShare < 1f && stage == 0 && pv + 30f < lastPct) stage = 1
        lastPct = pv
        val overall = when {
            item.videoShare >= 1f -> pv
            stage == 0 -> pv * item.videoShare
            else -> 100f * item.videoShare + pv * (1f - item.videoShare)
        }.coerceIn(0f, 99f)
        val etaSec = eta.toLong()

        DownloadStore.updateIfActive(itemId) {
            it.copy(status = DlStatus.RUNNING, progress = overall, eta = if (etaSec > 0) etaSec else 0L)
        }

        val pct = overall.toInt()
        val now = System.currentTimeMillis()
        if (pct != lastNotifPct && now - lastNotifAt > 700) {
            lastNotifPct = pct
            lastNotifAt = now
            val etaText = formatEta(etaSec)
            pushNotification(item.title, pct, false, if (etaText.isEmpty()) "%$pct" else "%$pct • $etaText")
        }
    }

    private fun findOutput(dir: File): File? =
        dir.listFiles()
            ?.filter {
                it.isFile && it.name.startsWith("dl.") &&
                    it.name.count { c -> c == '.' } == 1 &&
                    !it.name.endsWith(".part") && !it.name.endsWith(".ytdl")
            }
            ?.maxByOrNull { it.length() }

    // ------------------------------------------------------------------ Galeriye kaydet

    private fun mimeFor(ext: String, audio: Boolean): String = when (ext.lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> if (audio) "audio/webm" else "video/webm"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "opus", "ogg" -> "audio/ogg"
        else -> if (audio) "audio/*" else "video/*"
    }

    private fun sanitize(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "")
            .trim().trimEnd('.').take(100).ifBlank { "video" }

    private fun saveToGallery(file: File, title: String, audio: Boolean): Pair<Uri, String> {
        val ext = file.extension.lowercase()
        val mime = mimeFor(ext, audio)
        val resolver = applicationContext.contentResolver
        val isAudioFile = audio || mime.startsWith("audio/")
        val collection = if (isAudioFile) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val folder = (if (isAudioFile) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) +
            "/SW Video Yükleyici"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "${sanitize(title)}.$ext")
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("Dosya oluşturulamadı")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Dosya yazılamadı")
            out.use { o -> file.inputStream().use { it.copyTo(o, 256 * 1024) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri to mime
    }

    // ------------------------------------------------------------------ Bildirimler

    private fun openAppIntent(): PendingIntent {
        val i = applicationContext.packageManager.getLaunchIntentForPackage(applicationContext.packageName)
            ?: Intent()
        return PendingIntent.getActivity(
            applicationContext, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun progressNotification(title: String, pct: Int, indeterminate: Boolean, text: String): Notification {
        val cancel = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)
        return NotificationCompat.Builder(applicationContext, App.CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, indeterminate)
            .setContentIntent(openAppIntent())
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "İptal", cancel)
            .build()
    }

    private fun pushNotification(title: String, pct: Int, indeterminate: Boolean, text: String) {
        runCatching { nm.notify(notifId, progressNotification(title, pct, indeterminate, text)) }
    }

    private fun notifyDone(title: String, uri: Uri, mime: String) {
        runCatching {
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val pi = PendingIntent.getActivity(
                applicationContext, notifId, view,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(applicationContext, App.CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("İndirme tamamlandı")
                .setContentText(title)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(notifId + 1, n)
        }
    }

    private fun notifyFailed(title: String, msg: String) {
        runCatching {
            val n = NotificationCompat.Builder(applicationContext, App.CH_DONE)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("İndirme başarısız")
                .setContentText("$title — $msg")
                .setStyle(NotificationCompat.BigTextStyle().bigText("$title\n$msg"))
                .setContentIntent(openAppIntent())
                .setAutoCancel(true)
                .build()
            nm.notify(notifId + 1, n)
        }
    }
}
