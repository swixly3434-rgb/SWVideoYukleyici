@file:OptIn(ExperimentalMaterial3Api::class)

package com.sw.videoyukleyici

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            SWTheme {
                RootScreen(vm = vm, beforeDownload = { ensureNotificationPermission() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Başka uygulamadan "Paylaş > SW Video Yükleyici" ile gelen linki kutuya koyar. */
    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            vm.onUrlChange(text)
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

// =============================================================================== Kök ekran

@Composable
fun RootScreen(vm: MainViewModel, beforeDownload: () -> Unit) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val downloads by vm.downloads.collectAsStateWithLifecycle()
    val activeCount = downloads.count { it.status.isActive }

    LaunchedEffect(Unit) {
        vm.events.collect { msg ->
            val started = msg.startsWith("İndirme başladı")
            val r = snackbar.showSnackbar(message = msg, actionLabel = if (started) "Göster" else null)
            if (r == SnackbarResult.ActionPerformed) tab = 1
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("Ana Menü") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = {
                        BadgedBox(badge = { if (activeCount > 0) Badge { Text("$activeCount") } }) {
                            Icon(AppIcons.Download, contentDescription = null)
                        }
                    },
                    label = { Text("İndirilenler") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) {
                HomeScreen(
                    vm = vm,
                    onDownload = { d, q ->
                        beforeDownload()
                        vm.download(d, q)
                    }
                )
            } else {
                DownloadsScreen(
                    items = downloads,
                    onCancel = vm::cancel,
                    onRetry = vm::retry,
                    onRemove = vm::remove,
                    onOpen = { openFile(ctx, it) },
                    onShare = { shareFile(ctx, it) }
                )
            }
        }
    }
}

// =============================================================================== Ana Menü

@Composable
fun HomeScreen(vm: MainViewModel, onDownload: (VideoDetails, Quality) -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val engine by Engine.status.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // --- Başlık
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.logo),
                    contentDescription = null,
                    modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp))
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    "SW Video Yükleyici",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                if (vm.updating) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                } else {
                    IconButton(onClick = { vm.updateEngine() }) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "yt-dlp'yi güncelle",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // --- Link kutusu
        item {
            OutlinedTextField(
                value = vm.url,
                onValueChange = vm::onUrlChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Video bağlantısını buraya yapıştırın") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    focus.clearFocus()
                    vm.analyzeNow()
                }),
                trailingIcon = {
                    if (vm.url.isNotEmpty()) {
                        IconButton(onClick = { vm.clear() }) {
                            Icon(Icons.Default.Close, contentDescription = "Temizle")
                        }
                    }
                }
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        val t = clipboard.getText()?.text.orEmpty()
                        if (t.isNotBlank()) {
                            focus.clearFocus()
                            vm.onUrlChange(t)
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(AppIcons.Paste, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Yapıştır")
                }
                Button(
                    onClick = {
                        focus.clearFocus()
                        vm.analyzeNow()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Videoyu Bul", fontWeight = FontWeight.Bold)
                }
            }
        }

        // --- Motor durumu
        when (val e = engine) {
            is EngineState.Loading -> item {
                InfoCard("Motor hazırlanıyor… İlk açılışta birkaç saniye sürebilir.")
            }
            is EngineState.Failed -> item {
                InfoCard("Motor başlatılamadı: ${e.message}", isError = true)
            }
            is EngineState.Ready -> {}
        }

        // --- Sonuç alanı
        when (val s = state) {
            is UiState.Idle -> item { HintCard() }
            is UiState.Loading -> item {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 28.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(Modifier.size(26.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(14.dp))
                    Text("Video bilgileri alınıyor…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            is UiState.Error -> item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "Video alınamadı",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(s.message, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = { vm.analyzeNow() }) { Text("Tekrar dene") }
                    }
                }
            }
            is UiState.Ready -> {
                val d = s.details
                item { VideoCard(d) }
                item {
                    Text(
                        "Kalite seçin",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                items(d.qualities, key = { it.label + it.selector }) { q ->
                    QualityRow(q) { onDownload(d, q) }
                }
            }
        }
    }
}

@Composable
fun InfoCard(text: String, isError: Boolean = false) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text,
            modifier = Modifier.padding(14.dp),
            style = MaterialTheme.typography.bodySmall,
            color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun HintCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Nasıl kullanılır?", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text(
                "1. YouTube, Instagram, TikTok, X, Facebook… uygulamasında videoyu açın\n" +
                    "2. Paylaş → Bağlantıyı kopyala\n" +
                    "3. Buraya yapıştırın, kaliteler otomatik listelensin\n" +
                    "4. İstediğiniz kaliteye dokunun, indirme başlasın",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "İpucu: Paylaş menüsünden doğrudan “SW Video Yükleyici”yi seçebilirsiniz.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun VideoCard(d: VideoDetails) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Box {
                AsyncImage(
                    model = d.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color.Black)
                )
                if (d.durationSec > 0) {
                    Text(
                        formatDuration(d.durationSec),
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Column(Modifier.padding(14.dp)) {
                Text(
                    d.title,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                val sub = listOf(d.uploader, d.site).filter { it.isNotBlank() }.joinToString(" • ")
                if (sub.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        sub,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun QualityRow(q: Quality, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(q.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (q.badge.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        q.badge,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            if (q.sizeBytes > 0) {
                Text(
                    "~" + formatSize(q.sizeBytes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Box(
            modifier = Modifier.size(40.dp).background(SWGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(AppIcons.Download, contentDescription = "İndir", tint = Color.White)
        }
    }
}

// =============================================================================== İndirilenler

@Composable
fun DownloadsScreen(
    items: List<DownloadItem>,
    onCancel: (DownloadItem) -> Unit,
    onRetry: (DownloadItem) -> Unit,
    onRemove: (DownloadItem) -> Unit,
    onOpen: (DownloadItem) -> Unit,
    onShare: (DownloadItem) -> Unit
) {
    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    AppIcons.Download,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text("Henüz indirme yok", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "İndirilenler",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        items(items, key = { it.id }) { item ->
            DownloadRow(
                item = item,
                onCancel = { onCancel(item) },
                onRetry = { onRetry(item) },
                onRemove = { onRemove(item) },
                onOpen = { onOpen(item) },
                onShare = { onShare(item) }
            )
        }
    }
}

@Composable
fun DownloadRow(
    item: DownloadItem,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onRemove: () -> Unit,
    onOpen: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = item.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(104.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        statusText(item),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (item.status == DlStatus.FAILED) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (item.status.isActive) {
                Spacer(Modifier.height(10.dp))
                if (item.status == DlStatus.RUNNING && item.progress > 0f) {
                    LinearProgressIndicator(
                        progress = { item.progress / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                when (item.status) {
                    DlStatus.QUEUED, DlStatus.RUNNING, DlStatus.MERGING ->
                        TextButton(onClick = onCancel) { Text("İptal") }
                    DlStatus.DONE -> {
                        TextButton(onClick = onOpen) { Text("Aç") }
                        TextButton(onClick = onShare) { Text("Paylaş") }
                        IconButton(onClick = onRemove) {
                            Icon(Icons.Default.Delete, contentDescription = "Listeden kaldır")
                        }
                    }
                    DlStatus.FAILED, DlStatus.CANCELED -> {
                        TextButton(onClick = onRetry) { Text("Tekrar dene") }
                        IconButton(onClick = onRemove) {
                            Icon(Icons.Default.Delete, contentDescription = "Listeden kaldır")
                        }
                    }
                }
            }
        }
    }
}

private fun statusText(i: DownloadItem): String = when (i.status) {
    DlStatus.QUEUED -> "${i.qualityLabel} • Sırada…"
    DlStatus.RUNNING -> {
        val eta = formatEta(i.eta)
        "${i.qualityLabel} • %${i.progress.toInt()}" + if (eta.isEmpty()) "" else " • $eta"
    }
    DlStatus.MERGING -> "${i.qualityLabel} • Birleştiriliyor / kaydediliyor…"
    DlStatus.DONE -> {
        val size = formatSize(i.sizeBytes)
        "${i.qualityLabel} • Tamamlandı" + if (size.isEmpty()) "" else " • $size"
    }
    DlStatus.FAILED -> i.error ?: "İndirme başarısız"
    DlStatus.CANCELED -> "İptal edildi"
}

// =============================================================================== Dosya aç / paylaş

private fun openFile(ctx: Context, item: DownloadItem) {
    val uri = item.uri?.let { Uri.parse(it) } ?: return
    val i = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, item.mime ?: "video/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Dosya açılamadı (silinmiş olabilir)", Toast.LENGTH_SHORT).show()
    }
}

private fun shareFile(ctx: Context, item: DownloadItem) {
    val uri = item.uri?.let { Uri.parse(it) } ?: return
    val i = Intent(Intent.ACTION_SEND).apply {
        type = item.mime ?: "video/*"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        ctx.startActivity(Intent.createChooser(i, "Paylaş"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
    }
}
