package com.sw.videoyukleyici

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.lang.reflect.InvocationTargetException
import kotlin.concurrent.thread

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        createChannels()
        DownloadStore.init(this)
        Engine.start(this)
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "İndirme durumu", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Tamamlanan indirmeler", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    companion object {
        const val CH_PROGRESS = "sw_progress"
        const val CH_DONE = "sw_done"
    }
}

sealed interface EngineState {
    object Loading : EngineState
    object Ready : EngineState
    data class Failed(val message: String) : EngineState
}

/** yt-dlp + ffmpeg motorunu arka planda başlatır. */
object Engine {
    private val ready = CompletableDeferred<Unit>()
    private val _status = MutableStateFlow<EngineState>(EngineState.Loading)
    val status: StateFlow<EngineState> = _status

    private const val PREFS = "sw_engine"
    private const val KEY_LAST_UPDATE = "last_update"
    private const val DAY_12H = 12L * 60 * 60 * 1000

    fun start(app: Application) {
        thread(name = "engine-init") {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                _status.value = EngineState.Ready
                ready.complete(Unit)
            } catch (t: Throwable) {
                _status.value = EngineState.Failed(t.message ?: t.toString())
                ready.completeExceptionally(t)
                return@thread
            }
            // Siteler sık değiştiği için yt-dlp'yi günde en fazla 2 kez sessizce güncelle
            try {
                val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val last = prefs.getLong(KEY_LAST_UPDATE, 0L)
                if (System.currentTimeMillis() - last > DAY_12H) {
                    updateInternal(app)
                    prefs.edit().putLong(KEY_LAST_UPDATE, System.currentTimeMillis()).apply()
                }
            } catch (_: Throwable) {
            }
        }
    }

    suspend fun await() = ready.await()

    /** Elle güncelleme. Kullanıcıya gösterilecek mesajı döndürür. */
    suspend fun update(ctx: Context): String = withContext(Dispatchers.IO) {
        await()
        val result = updateInternal(ctx.applicationContext)
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putLong(KEY_LAST_UPDATE, System.currentTimeMillis()).apply()
        if (result.contains("ALREADY", ignoreCase = true)) "yt-dlp zaten güncel ✓"
        else "yt-dlp güncellendi ✓"
    }

    /**
     * Kütüphanenin güncelleme fonksiyonunu çağırır. Kütüphane sürümleri arasında
     * "kanal" parametresinin tipi değişebildiği için yansıma (reflection) ile güvenli çağrılır.
     */
    private fun updateInternal(ctx: Context): String {
        val ydl = YoutubeDL.getInstance()
        val methods = ydl.javaClass.methods.filter { it.name == "updateYoutubeDL" }
        val m2 = methods.firstOrNull { it.parameterTypes.size == 2 }
        val m1 = methods.firstOrNull { it.parameterTypes.size == 1 }
        try {
            val result: Any? = when {
                m2 != null -> m2.invoke(ydl, ctx, findStableChannel(m2.parameterTypes[1]))
                m1 != null -> m1.invoke(ydl, ctx)
                else -> throw IllegalStateException("Güncelleme fonksiyonu bulunamadı")
            }
            return result?.toString() ?: "DONE"
        } catch (e: InvocationTargetException) {
            throw (e.targetException ?: e)
        }
    }

    private fun findStableChannel(t: Class<*>): Any? {
        if (t.isEnum) {
            return t.enumConstants?.firstOrNull { (it as Enum<*>).name.equals("STABLE", ignoreCase = true) }
        }
        runCatching { return Class.forName(t.name + "\$STABLE").getField("INSTANCE").get(null) }
        runCatching { return t.getField("STABLE").get(null) }
        runCatching { return t.getField("_STABLE").get(null) }
        runCatching {
            val comp = t.getField("Companion").get(null)
            return comp.javaClass.getMethod("get_STABLE").invoke(comp)
        }
        return null
    }
}
