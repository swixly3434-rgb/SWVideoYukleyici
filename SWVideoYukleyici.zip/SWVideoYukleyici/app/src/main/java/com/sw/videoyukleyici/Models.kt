package com.sw.videoyukleyici

import java.util.Locale

/** Kullanıcıya gösterilen tek bir kalite seçeneği. */
data class Quality(
    val label: String,       // "1080p", "MP3"
    val badge: String,       // "Full HD", "Sadece ses"
    val sizeBytes: Long,     // 0 = bilinmiyor
    val selector: String,    // yt-dlp -f değeri
    val audioOnly: Boolean,
    val videoShare: Float    // toplam indirmenin video payı (ilerleme çubuğu için)
)

data class VideoDetails(
    val url: String,
    val title: String,
    val uploader: String,
    val site: String,
    val thumbnail: String?,
    val durationSec: Long,
    val qualities: List<Quality>
)

sealed interface UiState {
    object Idle : UiState
    object Loading : UiState
    data class Error(val message: String) : UiState
    data class Ready(val details: VideoDetails) : UiState
}

enum class DlStatus {
    QUEUED, RUNNING, MERGING, DONE, FAILED, CANCELED;

    val isActive: Boolean get() = this == QUEUED || this == RUNNING || this == MERGING
}

data class DownloadItem(
    val id: String,
    val url: String,
    val title: String,
    val thumbnail: String?,
    val qualityLabel: String,
    val selector: String,
    val audioOnly: Boolean,
    val videoShare: Float,
    val status: DlStatus = DlStatus.QUEUED,
    val progress: Float = 0f,
    val eta: Long = 0L,
    val uri: String? = null,
    val mime: String? = null,
    val sizeBytes: Long = 0L,
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

object UrlUtil {
    private val urlRegex = Regex("""(https?://|www\.)[^\s<>"']+""", RegexOption.IGNORE_CASE)
    private val completeRegex = Regex("""^https?://[^/\s]+\.[a-z]{2,}(:\d+)?(/.*)?$""", RegexOption.IGNORE_CASE)

    /** Yapıştırılan metnin içinden ilk linki çıkarır (paylaşım metinlerinde link genelde yazının içindedir). */
    fun extract(text: String): String? {
        val t = text.trim()
        if (t.isEmpty()) return null
        val m = urlRegex.find(t)
        if (m != null) {
            var u = m.value.trimEnd('.', ',', ')', ']', '!', ';')
            if (u.startsWith("www.", ignoreCase = true)) u = "https://$u"
            return u
        }
        // "youtu.be/xxxx" gibi şemasız linkler
        if (!t.contains(' ') && t.contains('.') && t.contains('/')) return "https://$t"
        return null
    }

    fun looksComplete(u: String) = completeRegex.matches(u)
}

fun formatSize(bytes: Long): String {
    if (bytes <= 0) return ""
    val mb = bytes / 1048576.0
    return when {
        mb >= 1024 -> String.format(Locale.US, "%.2f GB", mb / 1024)
        mb >= 10 -> String.format(Locale.US, "%.0f MB", mb)
        mb >= 1 -> String.format(Locale.US, "%.1f MB", mb)
        else -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
    }
}

fun formatDuration(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

fun formatEta(sec: Long): String {
    if (sec <= 0) return ""
    val m = sec / 60
    val s = sec % 60
    return if (m > 0) "${m} dk ${s} sn" else "${s} sn"
}
