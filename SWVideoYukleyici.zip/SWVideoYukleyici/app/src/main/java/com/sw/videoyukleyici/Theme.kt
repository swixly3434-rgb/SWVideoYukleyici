package com.sw.videoyukleyici

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val SWYellow = Color(0xFFFFD60A)
val SWGreen = Color(0xFF22C55E)

private val SWColors = darkColorScheme(
    primary = SWYellow,
    onPrimary = Color(0xFF111111),
    secondary = SWGreen,
    onSecondary = Color.Black,
    background = Color(0xFF0B0B0D),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF16161A),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF212127),
    onSurfaceVariant = Color(0xFFA9A9B3),
    secondaryContainer = Color(0xFF3A3300),
    onSecondaryContainer = SWYellow,
    error = Color(0xFFFF6B6B),
    outline = Color(0xFF3A3A42)
)

@Composable
fun SWTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SWColors, content = content)
}
