package com.sw.videoyukleyici

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** İndirme listesi: hem arayüz hem indirme işçisi buradan okur/yazar. Bitenler telefonda saklanır. */
object DownloadStore {
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("sw_downloads", Context.MODE_PRIVATE)
        prefs = p
        val loaded = try {
            parse(p.getString("items", "[]") ?: "[]")
        } catch (e: Exception) {
            emptyList()
        }
        // Uygulama kapanırken yarım kalanlar "başarısız" görünür, kullanıcı tekrar deneyebilir
        _items.value = loaded.map {
            if (it.status.isActive) it.copy(status = DlStatus.FAILED, error = "İndirme yarıda kesildi") else it
        }
        persist()
    }

    @Synchronized
    fun add(item: DownloadItem) {
        _items.value = (listOf(item) + _items.value.filter { it.id != item.id }).take(60)
        persist()
    }

    @Synchronized
    fun get(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    @Synchronized
    fun update(id: String, f: (DownloadItem) -> DownloadItem) {
        var statusChanged = false
        _items.value = _items.value.map {
            if (it.id == id) {
                val n = f(it)
                if (n.status != it.status) statusChanged = true
                n
            } else it
        }
        if (statusChanged) persist()
    }

    /** Sadece hâlâ aktif olan indirmeyi günceller (iptal edilmiş olanı geri canlandırmaz). */
    @Synchronized
    fun updateIfActive(id: String, f: (DownloadItem) -> DownloadItem) {
        val cur = get(id) ?: return
        if (!cur.status.isActive) return
        update(id, f)
    }

    @Synchronized
    fun remove(id: String) {
        _items.value = _items.value.filter { it.id != id }
        persist()
    }

    // ------------------------------------------------------------------ saklama

    private fun persist() {
        val p = prefs ?: return
        val arr = JSONArray()
        _items.value.forEach { arr.put(toJson(it)) }
        p.edit().putString("items", arr.toString()).apply()
    }

    private fun toJson(i: DownloadItem) = JSONObject().apply {
        put("id", i.id)
        put("url", i.url)
        put("title", i.title)
        put("thumb", i.thumbnail ?: "")
        put("q", i.qualityLabel)
        put("sel", i.selector)
        put("audio", i.audioOnly)
        put("vshare", i.videoShare.toDouble())
        put("status", i.status.name)
        put("uri", i.uri ?: "")
        put("mime", i.mime ?: "")
        put("size", i.sizeBytes)
        put("error", i.error ?: "")
        put("created", i.createdAt)
    }

    private fun parse(s: String): List<DownloadItem> {
        val arr = JSONArray(s)
        val out = ArrayList<DownloadItem>()
        for (n in 0 until arr.length()) {
            val o = arr.getJSONObject(n)
            out += DownloadItem(
                id = o.getString("id"),
                url = o.optString("url"),
                title = o.optString("title"),
                thumbnail = o.optString("thumb").ifEmpty { null },
                qualityLabel = o.optString("q"),
                selector = o.optString("sel"),
                audioOnly = o.optBoolean("audio"),
                videoShare = o.optDouble("vshare", 1.0).toFloat(),
                status = runCatching { DlStatus.valueOf(o.optString("status")) }.getOrDefault(DlStatus.FAILED),
                progress = 0f,
                uri = o.optString("uri").ifEmpty { null },
                mime = o.optString("mime").ifEmpty { null },
                sizeBytes = o.optLong("size"),
                error = o.optString("error").ifEmpty { null },
                createdAt = o.optLong("created")
            )
        }
        return out
    }
}
