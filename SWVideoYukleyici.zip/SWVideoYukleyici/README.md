# SW Video Yükleyici

Linki yapıştır → video, kapak, başlık ve tüm kaliteler listelensin → dokun, indir.
YouTube, Instagram, TikTok, X, Facebook, Vimeo ve yt-dlp'nin desteklediği 1000+ site.

Motor: yt-dlp + ffmpeg (youtubedl-android 0.18.1). Arayüz: Jetpack Compose.

## APK'yı GitHub'da derleme
1. GitHub'da yeni repo aç, bu klasördeki **tüm dosyaları** (`.github` klasörü dahil) yükle.
2. Repo > **Actions** sekmesi > "APK Derle" otomatik başlar (yaklaşık 5-8 dk). Başlamazsa "Run workflow".
3. Bitince APK iki yerde olur:
   - Repo > **Releases** (sağ taraf) > `SW-Video-Yukleyici.apk`
   - Actions > ilgili çalışma > Artifacts > `SW-Video-Yukleyici-APK`
4. APK'yı telefona indir, kur ("bilinmeyen kaynaklara izin ver" gerekir).

Videolar: Galeri / Movies / SW Video Yükleyici (ses: Music / SW Video Yükleyici).
Minimum Android 10.
